package com.buran.ExamProject.repositories;

import org.springframework.data.repository.CrudRepository;

import com.buran.ExamProject.models.Idea;



public interface IdeaRepository extends CrudRepository<Idea, Long> {

}
