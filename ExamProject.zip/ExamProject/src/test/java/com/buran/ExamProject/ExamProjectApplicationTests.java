package com.buran.ExamProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
